#include <stdio.h>
#include <string.h>

/*Saya Novaldi Sandi Ago 2003941
mengerjakan Soal no 11 dalam mata kuliah Struktur Data
untuk keberkahanNya maka saya tidak melakukan kecurangan
seperti yang telah dispesifikasikan. Aamiin*/

void swap(char word[][100], int depan[], int a);
int banyak(char word[]);