#include <stdio.h>
#include <string.h>

/*Saya Novaldi Sandi Ago 2003941
mengerjakan Soal no 1 dalam mata kuliah Struktur Data
untuk keberkahanNya maka saya tidak melakukan kecurangan
seperti yang telah dispesifikasikan. Aamiin*/

int banyak(char word[], int i);
void sorting(int much[], int index[], int i);