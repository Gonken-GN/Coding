#include "header.h"

/*Saya Novaldi Sandi Ago 2003941
mengerjakan Soal no 11 dalam mata kuliah Struktur Data
untuk keberkahanNya maka saya tidak melakukan kecurangan
seperti yang telah dispesifikasikan. Aamiin*/

void tampil(int arr[], int top){
	for(int i = top-1; i >= 0; i--)
		printf("%d\n", arr[i]);
	printf("-1\n");
}