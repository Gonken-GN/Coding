#include <stdio.h>
#include <string.h>
void cek(int n, char nama1[n][100], int m, char nama2[m][100]);